BWI Bundesmessenger auf Basis von Matrix Synapse
========================================================

1. Übersicht
2. PoC
3. Installationsbeispiele 

[Synapse](https://github.com/matrix-org/synapse) ist die aktuelle Implementation des [Matrix Protokoll](https://matrix.org).
Das Helm-Chart für den Bundesmessenger wurde aus dem Helm Chart von [Alexander Olofsson](https://gitlab.com/ananace/charts/-/tree/master/charts/matrix-synapse) entwickelt.
Die größten Änderungen zu dem zugrunde liegenden Chart sind:
- Anpassungen im Storageumfeld
- Änderung des Sets für die Worker auf Statefulsets
- Änderung der Benamung/Transport der Pod-Names in die Dienste, für eineindeutiges Logging und Auswertung der internen Kommunikation
- feste PersistentVolumeClaims für eigenen Postgresql-Server und Media-Worker
- Einfügen/Anpassen von Ingress-Routen 
- Hinzufügen eines Virenscanners (ClamAV) (TODO: Einbringung des Contentscanners zum aktivieren des Virenscanners)
- Hinzufügen des Synapse Admin von [Awesome-Technologies](https://github.com/Awesome-Technologies/synapse-admin) zur Administration der Instanz (aktuell auf nur intern erreichbarer Domain)
- Konfiguration des Sygnal-Push-Dienstes
- Konfiguration des kompletten Dienstes für das ServiceMonitoring per Prometheus (wird automatisch an Clustereigenen Prometheus promoted)
- Integration eines CoTurn-Servers zur Nutzung der VoIP-Dienste (TODO: Testen der Freischaltung)

Für Fragen zur Anwendung des Helm-Charts, Konfiguration und Deployment steht Ihnen Christian.Steinke@bwi.de gerne zur Verfügung.

## Voraussetzungen

- Kubernetes 1.19+
- Helm 3.0+
- Ingress Controller (NginX) im Cluster installiert
- vorgelagerte Loadbalancer und vorkonfigurierte Firewalls, um den Service in vollem Umfang zu nutzen
- ein "existingClaim" (persistent volume claim) mit dem Namen "matrix-synapse" (empfohlen 10GB) für den Media-Worker als Speicher. 
Sollte die storageClass nfs-client nicht existent sein, muss diese erstellt oder mit dem folgenden Parameter gesetzt werden:

    helm install bundesmessenger nextmessage/matrix-synapse --set persistence.storageClass=STORAGECLASS

**Anmerkung** Matrix benötigt valide Zertifikate um voll funktionsfähig zu sein.

## PoC

So installieren Sie eine POC-Umgebung

Unser Helm Chart kann die Installation von Matrix/Synapse Proof of Concept (POC) Umgebungen übernehmen. Unsere Standard-POC-Umgebung ist ein 4-Node-Cluster mit vanilla Kubernetes, auf dem wir unsere Testumgebung bereitstellen, was zu einem voll funktionsfähigen Synapse-Server mit Element Web führt, der zur Durchführung eines POC verwendet werden kann. Lokale Produktionsbereitstellungen verwenden dasselbe Installationsprogramm und denselben Operator, sind jedoch für die Bereitstellung in einer vollständigen Kubernetes-Umgebung vorgesehen und müssen erst noch getestet werden und das PoC erfolgreich verlassen.

POC-Anlagen sind nicht dazu bestimmt, zu Produktionszwecken betrieben zu werden. Sie sollten eine andere Installation für Ihre Produktionsumgebung planen. Die Einstellungen, die Sie mit dem Installationsprogramm verwenden, können für Ihre Produktionsinstallation übernommen, Ihre Räume und Bereiche jedoch nicht.

Um mit einer POC-Installation zu beginnen, müssen mehrere Dinge berücksichtigt werden, die in diesem Leitfaden behandelt werden:

Hostnamen/DNS
Maschinengröße
Betriebssystem
Benutzer
Netzwerkbesonderheiten
Postgresql-Datenbank
TURN-Server
SSL-Zertifikate
Zusätzliche Konfigurationselemente
Sobald diese Bereiche abgedeckt sind, können Sie eine POC-Umgebung installieren!

### Hostnamen/DNS
Sie benötigen Hostnamen für die folgenden Infrastrukturkomponenten:

Elementserver (erforderlich)
Synapse-Server (erforderlich)
CoTurn-Server (optional)
Synapse-Admin-Server (empfohlen für nur intern erreichbar, .local-Domain, ansonsten muss eine zusätzliche Sicherheitsbarriere hier berücksichtigt werden :) )
Monitoring (empfohlen)
 
Diese Hostnamen müssen in die entsprechenden IP-Adressen aufgelöst werden. Wenn Sie über einen geeigneten DNS-Server mit Einträgen für diese Hostnamen verfügen, können Sie loslegen

### Maschinengröße
Für die Durchführung eines Proof of Concept mit unserem Installationschart unterstützen wir nur die x86_64-Architektur und empfehlen die folgenden Mindestanforderungen:

Kein Verbund: 4 vCPUs/CPUs und 16 GB RAM
Föderation: 8 vCPUs/CPUs und 32 GB RAM
(TODO: Gegenprüfung!!!)
 
### Betriebssystem
Im Rahmen der DVS und der Entwicklung des Bundesmessenger ist die Nutzung von OSADL-Images die wahrscheinlichste Variante.
Aus der Sicht der Sicherheit ist zu Alpine oder Debian bzw. Ubuntu-Server (LTS) zu raten. Es gibt aber keine Einschränkungen zu RedHead oder SLES, jedoch müssen Abhängigkeiten zu nötigen Paketen selbst vorgenommen werden.

### Netzwerk
Der Messengerservice muss Inhalte binden und bereitstellen über:

Port 80 TCP
Port 443 TCP

Entsprechende Ports müssen auch entweder lokal auf der PoC-Umgebung freigegeben werden oder in der vorgeschalteten Sicherheitsinfrastruktur.

### Postgresql-Datenbank
Die Installation erfordert, dass Sie eine postgresql-Datenbank mit einem LOCALE von C und UTF8-Codierung eingerichtet haben. 
Siehe https://github.com/matrix-org/synapse/blob/develop/docs/postgres.md#set-up-database für weitere Details.

Wenn Sie diese bereits haben, notieren Sie sich bitte den Datenbanknamen, den Benutzer und das Passwort, da Sie diese benötigen, um mit der Installation zu beginnen. (per Parameter zu übergeben oder in der value.yaml anzupassen)

Wenn Sie noch keine Datenbank haben, richtet das PoC-Installationsprogramm PostgreSQL in Ihrem Namen ein. Dies ist per Default so hinterlegt. Dafür benötigt das Chart jedoch ein festes VolumeClaim der StorageClass "nfs-client". Dies kann geändert werden (siehe oben)

### TURN-Server
Für Installationen, in denen Sie Videokonferenzfunktionen verwenden möchten, muss ein TURN-Server installiert und verfügbar sein, damit die Apps und der Web-Client ihn verwenden kann.
Dieser wird per Default im gleichen Namespace wie der Service installiert und per Ingress auch konfiguriert. 
Weitere Details zur Konfiguration und Anweisungen dazu finden Sie hier: https://github.com/matrix-org/synapse/blob/master/docs/turn-howto.md 
 
HIER MUSS JETZT DIE KONFIG VOM COTURN ANGEPASST WERDEN UND ENTSPRECHENDE PORT-FREIGABEN HIER ERKLÄRT WERDEN!!!

## Installation

Um eine Förderationsversion vom Matrix zu Nutzen, benötigen Sie eine öffentlich zugängliche Subdomain, auf der Kubernetes ein Ingress laufen hat.
Sie benötigen weiterhin auch einen Vermittler, entweder in Form des Well-Known `.well-known/matrix/server` Server oder einem SRV-Eintrag im DNS.

Wenn Sie einen well-known Eintrag verwenden, benötigen Sie ein gültiges Zertifikat für die Subdomain, auf der Sie Synapse bereitstellen möchten.
Wenn Sie einen SRV-Eintrag verwenden, benötigen Sie zusätzlich ein gültiges Zertifikat für die Hauptdomäne, die Sie für Ihre MXIDs (**M**atri**x** Nutzer **ID**s) verwenden.

## Installations Beispiele

Für mehr Informationen nutzen Sie die öffentlich erreichbaren Dokumentationen: [Synapse Dokumentation](https://github.com/matrix-org/synapse/blob/master/docs/federate.md)

### Auf der Hauptdomain / mit Subdomain MXIDs

Für eine möglichst einfache Matrix-Installation, können Sie Ihre Synapse-Installation auf der gewünschten HauptDomain für Ihre MXIDs ausführen.
Sollten Sie, zum Beispiel, die Domaine 'beispiel.org' besitzen und Sie möchten den Bundesmessenger darauf laufen lassen, reicht der folgende Aufruf des Charts:

    helm install bundesmessenger nextmessage/matrix-synapse --set serverName=beispiel.org --set wellknown.enabled=true

Dadurch würde Synapse mit Client-Server und Förderation eingerichtet werden, welche beide über `beispiel.org/_matrix` verfügbar sind, sowie ein lighttp Server, der auf die Förderationsanfragen auf `beispiel.org/.well-known/matrix/server` antwortet.

Es ist auch möglich, Synapse auf einer Subdomain laufen zu lassen, wobei diese dann Teil Ihrer MXIDs wird: (`@nutzer:matrix.beispiel.org` in folgenden Beispiel)

    helm install matrix-synapse nextmessage/matrix-synapse --set serverName=matrix.beispiel.org --set wellknown.enabled=true

### auf separater Subdomain

Für den Fall, Sie besitzen die Domain `beispiel.org` und Sie wollen die MXIDs in der Form `@nutzer:beispiel.org`, aber dennoch den Synapsedienst unter der Domain `matrix.beispiel.org` laufen lassen, bleiben Ihnen 2 Möglichkeiten: DNS oder well-known.

Für DNS
For DNS, you could install the chart as;

    helm install matrix-synapse ananace-charts/matrix-synapse --set serverName=example.com --set publicServerName=matrix.example.com

This will add federation endpoints to `example.com`, along with client endpoints on `matrix.example.com`. For this to work, you will need to have valid certs for both `example.com` as well as `matrix.example.com` for your Synapse to use.
To get federation working with such a setup, you would also need to add an SRV record to your DNS - for example;  

    _matrix._tcp.example.com 10 1 443 matrix.example.com

If you want to use a well-known file for federation instead of an SRV record, then your install might look more like;

    helm install matrix-synapse ananace-charts/matrix-synapse --set serverName=example.com --set publicServerName=matrix.example.com --set wellknown.enabled=true

With well-known federation, your client-to-server/public host is the one that needs to handle both client and federation traffic. On your main domain you'll instead only need something that can respond with a JSON file on the URL `example.com/.well-known/matrix/server` - which the included wellknown server will gladly do for you.  
Additionally, when using well-known federation, your Synapse cert only needs to be valid for `matrix.example.com`.

&nbsp;

More advanced setups can be made using `ingress.hosts`, `ingress.csHosts`, and `ingress.wkHosts` for server-server, client-server, and well-known endpoints respectively.  
Alternatively, you can use your own ingress setup, or switch the main service to `LoadBalancer` and add a TLS listener.

## Upgrading

```
# Delete the old StatefulSet but leave the Pod alive
kubectl delete statefulset --cascade=orphan matrix-synapse-redis-master

# Upgrade the chart and create a new StatfulSet for redis
helm upgrade matrix-synapse matrix-synapse

# Delete the old Pod so the new StatefulSet can take over
kubectl delete pod matrix-synapse-redis-master-0   
```
